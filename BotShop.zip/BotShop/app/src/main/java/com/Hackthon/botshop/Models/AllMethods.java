package com.Hackthon.botshop.Models;

public class AllMethods {

    public static String name = "";

}
